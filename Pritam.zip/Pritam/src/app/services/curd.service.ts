import { APIResult,DATA } from 'src/app/interface/test';
import { API_CONFIG, API_URL } from 'src/app/utlis/data';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CurdService {
DATA: DATA[];
  httpOptions: { headers: HttpHeaders };
    constructor(private http: HttpClient) {
        this.httpOptions = {
            headers: new HttpHeaders(API_CONFIG),
        };
    }
    getData(): Promise<DATA[]> {
      const promise = new Promise<DATA[]>((objectData, objectDatareject) => {
          try {
              this.http.get(API_URL + '/get.php').subscribe(
                  (data: APIResult) => {
                      if (data.message === 'success') {
                          this.DATA = data.data;
                          console.log(this.DATA);
                          objectData(this.DATA);
                      }
                  },
                  (error) => {
                      objectDatareject(error);
                  }
              );
          } catch (error) {
              // console.log(error);
              objectDatareject('error');
          }
      });
      return promise;
  }
    setData(objData: DATA) {
      const promise = new Promise((addObjectData, reject) => {
        const param = '?name=' + objData.name + '&address=' + objData.address + '&email=' + objData.email + '&password=' + objData.password;
        try {
            this.http.get(API_URL + '/add.php' + param).subscribe(
                (data: APIResult) => {
                    if (data.message === 'success') {
                        addObjectData(data.message);
                    }
                },
                (error) => {
                    reject(error);
                }
            );
        } catch (error) {
            reject('error');
        }
    });
      return promise;
}

updateData(id: number, update: DATA): Promise<DATA[]> {
    const promise = new Promise((updateObjectData, reject) => {
      const param = '&name=' + update.name + '&address=' + update.address + '&email=' + update.email + '&password=' + update.password;
      try {
            this.http.get(API_URL + '/update.php' + '?id=' + id + param).subscribe(
              (updata: APIResult) => {
                if (updata.message === 'success') {
                  const mess = updata.message;
                  updateObjectData(mess);
                }
              },
                (error) => {
                    reject(error);
                }
            );
        } catch (error) {
            reject('error');
        }
    });
    return promise;
}

deleteData(id: number): Promise<DATA[]> {
    const promise = new Promise((deleteObjectData, reject) => {
      const param = '?id=' + id;
      try {
            this.http.get(API_URL + '/delete.php' + param).subscribe(
                (deldata: APIResult) => {
                    if (deldata.message === 'success') {
                      deleteObjectData(deldata.message);
                    }
                },
                (error) => {
                    reject(error);
                }
            );
        } catch (error) {
            reject('error');
        }
    });

    return promise;
}

setAdmin(objData: DATA) {
  const promise = new Promise((addObjectData, reject) => {
    const param = '?name=' + objData.name + '&address=' + objData.address + '&email=' + objData.email + '&password=' + objData.password;
    try {
        this.http.get(API_URL + '/addAdmin.php' + param).subscribe(
            (data: APIResult) => {
                if (data.message === 'success') {
                    addObjectData(data.message);
                }
            },
            (error) => {
                reject(error);
            }
        );
    } catch (error) {
        reject('error');
    }
});
  return promise;
}
mahAdmin(email: string, password: string) {
  const promise = new Promise((checkObjectData, reject) => {
    const param = '?email=' + email + '&password=' + password;
    try {
        this.http.get(API_URL + '/check.php' + param).subscribe(
            (data: APIResult) => {
                  checkObjectData(data.message);
            },
            (error) => {
              checkObjectData(error);
            }
        );
    } catch (error) {
        reject('error');
    }
});
  return promise;
}

getemailData(email: string): Promise<DATA[]> {
  const promise = new Promise<DATA[]>((objectData, objectDatareject) => {
      const param = '?email=' + email;
      try {
          this.http.get(API_URL + '/get.php' + param).subscribe(
              (data: APIResult) => {
                  if (data.message === 'success') {
                      this.DATA = data.data;
                      console.log(this.DATA);
                      objectData(this.DATA);
                  }
              },
              (error) => {
                  objectDatareject(error);
              }
          );
      } catch (error) {
          // console.log(error);
          objectDatareject('error');
      }
  });
  return promise;
}
}
