export interface APIResult {
  message: string;
  data: DATA[];
}

export interface DATA {
  id: number;
  address: string;
  email: string;
  name: string;
  password: string;
}
