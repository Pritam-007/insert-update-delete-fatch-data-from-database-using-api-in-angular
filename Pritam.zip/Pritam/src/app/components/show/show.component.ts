import { Component, OnInit } from '@angular/core';
// import { DATA } from 'src/app/interface/test';
import { Router } from '@angular/router';
import { CurdService } from 'src/app/services/curd.service';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.scss']
})
export class ShowComponent implements OnInit {
  _email: string;
  _password: string;
  constructor(private testService: CurdService,
              private router: Router) { }

  ngOnInit(): void {
  }

  async onClick(email: string, password: string) {
    console.log("Login Validation onclick");
    const mData = await this.testService.mahAdmin(email, password);
    console.log(mData);
    if (mData === 'success') {
      this.router.navigate(['afterlogin']);
    } else{
      this.router.navigate(['dashboard']);
    }
    this._email = '';
    this._password = '';
}
}
