import { Component, OnInit } from '@angular/core';
import { CurdService } from 'src/app/services/curd.service';
import { DATA } from 'src/app/interface/test';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  isshow = false;
  isemail = false;
  _email: string;
  _address: string;
  _password: string;
  _name: string;
  _id: number;
  _semail: string;
  upData: any;
  delData: any;
  objectData: DATA[] ;
  emailData: DATA[];
  constructor(private testService: CurdService,
              private router: Router) { }

  ngOnInit() {
    console.log("Login-OnInit");
    this.getData();
  }
  async onClick() {
    console.log("onclick");
    const newData: DATA = {
        id: this._id,
        name: this._name,
        address: this._address,
        email: this._email,
        password: this._password
    };
    const scrData = await this.testService.setData(newData);
    if (scrData === 'success') {
        this.getData();
    }
    this._name = '';
    this._address = '';
    this._email = '';
    this._password = '';
}

  async getData() {
    this.testService
        .getData()
        .then((data) => {
            console.log(data);
            this.objectData = data;
            console.log(this.objectData);
        })
        .catch((e) => {
            console.log(e);
        });
  }
  async updateData(uid: number) {
    const updateData: DATA = {
      id: this._id,
      name: this._name,
      address: this._address,
      email: this._email,
      password: this._password
    };
    console.log(uid);
    this.upData = await this.testService.updateData(uid, updateData);
    if (this.upData === 'success') {
      this.getData();
    }
    this._id = null;
    this._name = '';
    this._address = '';
    this._email = '';
    this._password = '';
}

async deleteData(id: number) {
  console.log(id);
  this.delData = await this.testService.deleteData(id);
  if (this.delData === 'success') {
    this.getData();
  }
  console.log(this.delData);
}

async getemailData(email: string) {
  this.testService
      .getemailData(email)
      .then((data) => {
          console.log(data);
          this.emailData = data;
          console.log(this.emailData);
      })
      .catch((e) => {
          console.log(e);
          this.router.navigate(['dashboard']);
      });
}
}
