import { Component, OnInit } from '@angular/core';
import { DATA } from 'src/app/interface/test';
import { CurdService } from '../../services/curd.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  _email: string;
  _address: string;
  _password: string;
  _name: string;
  _id: number;
  constructor(private curdservice: CurdService,
              private router: Router) { }

  ngOnInit(): void {
  }
  async onClick() {
    console.log("onclick");
    const newData: DATA = {
        id: this._id,
        name: this._name,
        address: this._address,
        email: this._email,
        password: this._password
    };
    const admData = await this.curdservice.setAdmin(newData);
    if(admData){
    this.router.navigate(['login']);
   }
    this._name = '';
    this._address = '';
    this._email = '';
    this._password = '';
}
}
