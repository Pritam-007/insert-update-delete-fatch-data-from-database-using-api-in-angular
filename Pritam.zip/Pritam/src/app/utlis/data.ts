export const API_URL = 'http://localhost/api';

export const API_CONFIG = {
    'Content-Type': 'application/json',
};
